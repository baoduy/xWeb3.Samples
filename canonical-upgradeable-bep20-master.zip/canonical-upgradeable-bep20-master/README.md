# Canonical-upgradeable-bep20
Implement an upgradeable bep20 contract

## Install dependency

```shell script
npm install
```

## Run unittests

Start ganache:
```shell script
npm run testrpc
```

Run unittests:
```shell script
npm run truffle:test
```

## Flatten

```shell script
npm run flatten
```